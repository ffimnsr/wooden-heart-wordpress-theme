<?php if ( is_active_sidebar( 'sidebar-3' ) ) { ?>
<div class="in-page-ads h-auto w-full mb-4">
	<?php dynamic_sidebar( 'sidebar-3' );  ?>
</div>
<?php } ?>
