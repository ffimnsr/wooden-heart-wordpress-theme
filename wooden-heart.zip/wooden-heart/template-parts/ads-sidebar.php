<aside class="ads-sidebar lg:mr-auto lg:w-40 mt-10 space-y-4">
	<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
		dynamic_sidebar( 'sidebar-2' );
	}
	?>
</aside>
