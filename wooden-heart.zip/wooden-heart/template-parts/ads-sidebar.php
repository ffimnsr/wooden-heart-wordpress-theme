<aside class="ads-sidebar mr-auto mt-10 w-40 space-y-4">
	<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
		dynamic_sidebar( 'sidebar-2' );
	}
	?>
</aside>
